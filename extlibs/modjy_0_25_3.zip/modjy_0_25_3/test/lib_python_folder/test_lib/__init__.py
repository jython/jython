# -*- coding: windows-1252 -*-

# Specify only the some_libs module.

#__all__ = ['some_libs', ]

# And define a simple function in here as well.

def stringTransform(s):
    return s.upper()
