Don't forget that you have to install the jython.jar file in
the WEB-INF/lib subdirectory of this directory. And there are
various configuration parameters you have to that are specific
to your environment.

Please see the installation documentation for more details.

http://modjy.xhaus.com/install.html
