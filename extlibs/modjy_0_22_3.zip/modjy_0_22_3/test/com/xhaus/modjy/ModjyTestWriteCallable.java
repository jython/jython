package com.xhaus.modjy;

class ModjyTestWriteCallable extends ModjyTestBase
	{

	public void testLineEndsNotTranslated ( )
		{
		// Spec says no translation on output
		}


	}
