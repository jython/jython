# -*- coding: windows-1252 -*-

def lib_function():
	return "This is a library function"
