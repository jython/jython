package jpkg.j;

public class K {
    public static String x = "from jpkg.j.K";
}