package jpkg;

public class L {
    public static String x = "from jpkg.L";
}