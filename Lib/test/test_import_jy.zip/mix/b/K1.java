package mix.b;

public class K1 {
    public static String x = "from mix.b.K1";
}
