package mix.j;

public class K2 {
    public static String x = "from mix.j.K2";
}
