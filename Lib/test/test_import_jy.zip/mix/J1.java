package mix;

public class J1 {
    public static String x = "from mix.J1";
}
