print "Executed: ", __file__
n0, n1, n2, n3, n4 = range(5)
