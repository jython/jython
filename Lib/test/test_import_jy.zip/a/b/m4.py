print "Executed: ", __file__
import sys
print repr(sys)
