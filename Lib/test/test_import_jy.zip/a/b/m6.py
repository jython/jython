print "Executed: ", __file__
from ..b.c import m, n1, n2
print repr(m)
print n1, n2
