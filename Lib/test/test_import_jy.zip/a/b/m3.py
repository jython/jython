print "Executed: ", __file__
import c.m
print repr(c.m)
